<?php
// required headers
header("Access-Control-Allow-Origin: http://localhost/rest-api-authentication-example/");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


function msg($success,$status,$message,$extra = []){
    return array_merge([
        'success' => $success,
        'status' => $status,
        'message' => $message
    ],$extra);
}

// files needed to connect to database
include_once 'config/database.php';
include_once 'objects/user.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
// instantiate user object
$user = new User($db);
// check email existence here


// get posted data
$data = json_decode(file_get_contents("php://input"));
$returnData = [];
// set product property values
$user->email = $data->email;
$email_exists = $user->emailExists();

// generate json web token
include_once 'config/core.php';
include_once 'libs/php-jwt-master/src/BeforeValidException.php';
include_once 'libs/php-jwt-master/src/ExpiredException.php';
include_once 'libs/php-jwt-master/src/SignatureInvalidException.php';
include_once 'libs/php-jwt-master/src/JWT.php';
use \Firebase\JWT\JWT;
// generate jwt will be here


// IF REQUEST METHOD IS NOT POST
if($_SERVER["REQUEST_METHOD"] != "POST"){
    $returnData = msg(0,404,'Page Not Found!');

    // CHECKING EMPTY FIELDS
if(!isset($data->email) 
    || !isset($data->password) 
    || empty(trim($data->email))
    || empty(trim($data->password))
    ){

  $fields = ['fields' => ['name','email','password', 'role', 'tel']];
    $returnData = msg(0,422,'Please Fill in all Required Fields!',$fields);
  }
        // IF THERE ARE NO EMPTY FIELDS THEN-
else{
    
    $email = trim($data->email);
    $password = trim($data->password);

 if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $returnData = msg(0,422,'Invalid Email Address!');
    }
    elseif(strlen($password) < 8){
        $returnData = msg(0,422,'Your password must be at least 8 characters long!'); 
      }
    }
  }

  else{
     $email = trim($data->email);
    $password = trim($data->password);
    try{

 $fetch_user_by_email = "SELECT * FROM `users` WHERE `email`=:email"; 
 $query_stmt = $db->prepare($fetch_user_by_email);
 $query_stmt->bindValue(':email', $email,PDO::PARAM_STR);
 $query_stmt->execute();

  // IF THE USER IS FOUNDED BY EMAIL 
  if($query_stmt->rowCount()){
      $row = $query_stmt->fetch(PDO::FETCH_ASSOC);
  
      $check_password = password_verify($password, $row['password']);
       if($check_password){

          $token = array( 
            "iat" => $issued_at, 
            "exp" => $expiration_time, 
            "iss" => $issuer, 
            "data" => array( 
              "id" => $user->id, 
              "name" => $user->name, 
              "email" => $user->email
       )
    ); 
          $jwt = JWT::encode($token, $key);
            $returnData =array( 
              'success' => 200,
              'message' => 'You have successfully logged in.',

              'data'=> array(
              'token' => $jwt, 
            ), 

              'user-info'=>array(
                'ID' => $row['id'], 
              'email' => $email, 
              'role' => $row['role'], 
              )
          );
}
}
   }

      catch(PDOException $e){
            $returnData = msg(0,500,$e->getMessage());
        }
  }


echo json_encode($returnData);
