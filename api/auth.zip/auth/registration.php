

<?php
include('config.php');
       $name = $_POST["name"];
       $email = $_POST["email"]; 
       $tel = $_POST["tel"]; 
       $password = $_POST["password"];



$sql = "SELECT * FROM users WHERE email = '".$email."'";
         $query = mysqli_query($conn, $sql);

       if (mysqli_num_rows($query)>0){
            $response = array("Error"=>"1", "message"=>"Email already exist, try another one");
        }

      $sql1 = "SELECT * FROM users WHERE tel = '".$tel."'";
         $query1 = mysqli_query($conn, $sql1);

       if (mysqli_num_rows($query1)>0){
            $response = array("Error"=>"1", "message"=>"Tel already exist, try another one");
        }
 
   else{

 $query2 = "INSERT INTO users (name, email, tel, password) VALUES('$name', '$email', '$tel', '$password')";
 $result = mysqli_query($conn, $query2) or die(mysqli_error($conn));

if($result==1){
	$response = array("status"=>"200", "message"=>"Successfully Registered");
}
else{
	$response = array("status"=>"000", "message"=>"Error Occured");

}

}
echo json_encode($response);

?>
