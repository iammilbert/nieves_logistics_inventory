<?php
$conn = mysqli_connect("localhost", "nieveslo_nievesdb", "Milbert@1995", "nieveslo_db");

?>
