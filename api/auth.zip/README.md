# php-login-registration-api-JWT
 We will create a simple Login and Registration RESTful API using PHP and MySQL Database. we will use the JWT to authenticate a user.
